# posenet-demo-ml5js
A posenet demo built using ml5.js

Live Demo - https://campusx-official.github.io/posenet-demo-ml5js/
